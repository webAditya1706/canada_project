const sidebar = document.getElementById('main_sidebar');
const overlay = document.querySelector('.overlay_mainsidebar');
const openSidebarBtn = document.getElementById('open_main_sidebar');

// Open sidebar
openSidebarBtn.addEventListener('click', function (event) {
    event.stopPropagation(); // Prevents document click from closing it immediately
    sidebar.classList.add('show_side_bar');
    overlay.style.display = 'block';
});

// Prevent closing when clicking inside sidebar
sidebar.addEventListener('click', function (event) {
    event.stopPropagation(); // Stops event from bubbling to document
});

// Close sidebar when clicking outside
document.addEventListener('click', function (event) {
    if (!sidebar.contains(event.target) && !openSidebarBtn.contains(event.target)) {
        sidebar.classList.remove('show_side_bar');
        overlay.style.display = 'none';
    }
});

// Close sidebar when clicking on overlay
overlay.addEventListener('click', function () {
    sidebar.classList.remove('show_side_bar');
    overlay.style.display = 'none';
});
